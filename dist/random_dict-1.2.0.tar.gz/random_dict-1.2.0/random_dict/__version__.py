"""Current version of package random_dict."""

__version__ = "1.2.0"
